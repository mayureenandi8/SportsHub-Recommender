# Ticket Meister

Ticket Meister is an application designed to help you to find tickets you need.

## Description

Project consists of the following modules:

- [backend](./backend) is an Express.js REST API fetching information from third-party ticket data sources (for example, Ticket Master).
- [frontend](./fronted) is an Angular web app allowing you to search for tickets and add reviews.

## Usage

If you don't want to install PostgreSQL locally you can use [docker-compose.yml](./docker-compose.yml), a Docker Compose file designed to run PostgreSQL database in a Docker container.

Run the following command to run PostgreSQL in Docker:

```bash
docker-compose up -d
```

Make sure that the database is up using the following command:

```bash
docker-compose ps
```

Run the previous command until you see that the database is up (might take some time).

**Please note that database credentials are stored in [database.env](./database.env)**

After the database up you can refer to README.md files for [backend](./backend/README.md) and [frontend](./frontend/README.md) projects.

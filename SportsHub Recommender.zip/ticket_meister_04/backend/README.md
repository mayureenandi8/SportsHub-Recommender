# Ticket Meister backend

Ticket Meister backend is an Express.js REST API fetching information from third-party ticket data sources (for example, Ticket Master).

## Usage

1. Check credentials and other parameters stored in [.env](.env) file. If you run PostgreSQL in Docker, you don't need to change anything.
2. Install all dependencies:

```bash
npm install
```

3. Create tables:

```bash
npm run create-tables
```

4. Run backend:

```bash
npm run start
```

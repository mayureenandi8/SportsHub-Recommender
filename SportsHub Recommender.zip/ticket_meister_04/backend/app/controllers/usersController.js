import moment from "moment";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";

dotenv.config();

import dbQuery from "../db/dbQuery";

import { validatePassword, isEmpty } from "../helpers/validations";

import { errorMessage, successMessage, status } from "../helpers/status";

const hashPassword = (password) => {
  const hashedPassword = bcrypt.hashSync(password, 10);

  return hashedPassword;
};

const comparePassword = (password, hashedPassword) => {
  return bcrypt.compareSync(password, hashedPassword);
};

const generateUserToken = (firstName, lastName, address, zipcode, username) => {
  const token = jwt.sign(
    {
      firstName,
      lastName,
      address,
      zipcode,
      username,
    },
    process.env.SECRET,
    { expiresIn: "3d" }
  );

  return token;
};

/**
 * Create A User
 * @param {object} req
 * @param {object} res
 * @returns {object} reflection object
 */
const createUser = async (req, res) => {
  const {
    firstName,
    lastName,
    address,
    zipcode,
    username,
    password,
    sports,
  } = req.body;

  if (
    isEmpty(firstName) ||
    isEmpty(lastName) ||
    isEmpty(address) ||
    isEmpty(zipcode) ||
    isEmpty(username) ||
    isEmpty(password)
  ) {
    errorMessage.error =
      "firstName, lastName, address, zipcode, username, and password fields cannot be empty";
    return res.status(status.bad).send(errorMessage);
  }
  if (!validatePassword(password)) {
    errorMessage.error = "Password must be more than 6 characters";
    return res.status(status.bad).send(errorMessage);
  }

  const createdAt = moment(new Date());
  const hashedPassword = hashPassword(password);
  const createUserQuery = `
    INSERT INTO users
    (
      first_name,
      last_name,
      address,
      zipcode,
      username,
      password,
      created_at
    )
    VALUES($1, $2, $3, $4, $5, $6, $7)
    RETURNING *
  `;
  const values = [
    firstName,
    lastName,
    address,
    zipcode,
    username,
    hashedPassword,
    createdAt,
  ];

  try {
    const { rows } = await dbQuery.query(createUserQuery, values);
    const dbResponse = rows[0];
    const token = generateUserToken(
      dbResponse.first_name,
      dbResponse.last_name,
      dbResponse.address,
      dbResponse.zipcode,
      dbResponse.username
    );

    successMessage.data = {
      id: dbResponse.id,
      firstName: dbResponse.first_name,
      lastName: dbResponse.last_name,
      address: dbResponse.address,
      zipcode: dbResponse.zipcode,
      username: dbResponse.username,
      createdAt: dbResponse.created_at,
      token: token,
    };

    return res.status(status.created).send(successMessage);
  } catch (error) {
    if (error.routine === "_bt_check_unique") {
      errorMessage.error = `User ${username} already exists`;
      return res.status(status.conflict).send(errorMessage);
    }
    errorMessage.error = `Operation was not successful: ${error.message}`;
    return res.status(status.error).send(errorMessage);
  }
};

/**
 * Signin
 * @param {object} req
 * @param {object} res
 * @returns {object} user object
 */
const authenticateUser = async (req, res) => {
  const { username, password } = req.body;

  if (isEmpty(username) || isEmpty(password)) {
    errorMessage.error = "Username or password are missing";
    return res.status(status.bad).send(errorMessage);
  }

  try {
    const {
      rows,
    } = await dbQuery.query("SELECT * FROM users WHERE username = $1", [
      username,
    ]);
    const dbResponse = rows[0];

    if (!dbResponse) {
      errorMessage.error = `User ${username} does not exist`;
      return res.status(status.notfound).send(errorMessage);
    }

    if (!comparePassword(password, dbResponse.password)) {
      errorMessage.error = "The password you provided is incorrect";
      return res.status(status.bad).send(errorMessage);
    }

    const token = generateUserToken(
      dbResponse.first_name,
      dbResponse.last_name,
      dbResponse.address,
      dbResponse.zipcode,
      dbResponse.username
    );

    successMessage.data = {
      id: dbResponse.id,
      firstName: dbResponse.first_name,
      lastName: dbResponse.last_name,
      address: dbResponse.address,
      zipcode: dbResponse.zipcode,
      username: dbResponse.username,
      createdAt: dbResponse.created_at,
      token: token,
    };

    return res.status(status.success).send(successMessage);
  } catch (error) {
    errorMessage.error = "Operation was not successful";
    return res.status(status.error).send(errorMessage);
  }
};

export { createUser, authenticateUser };

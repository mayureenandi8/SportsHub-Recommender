import moment from "moment";
import dotenv from "dotenv";

import dbQuery from "../db/dbQuery";
import { errorMessage, successMessage, status } from "../helpers/status";
import { fetchCategoriesFromDB } from "./eventsController";

dotenv.config();

/**
 * Creates a new review
 * @param {object} req
 * @param {object} res
 * @returns {object} reflection object
 */
const createReview = async (req, res) => {
  const { userId } = req.params;

  console.info(`Started creating a new review for user ${userId}`);

  const { categoryId, rating, review } = req.body;
  const now = moment();

  try {
    const { rows } = await dbQuery.query(
      `
      INSERT INTO reviews
      (
        user_id,
        category_id,
        review,
        rating,
        created_at
      )
      VALUES ($1, $2, $3, $4, $5)
      RETURNING *
      `,
      [userId, categoryId, review, rating, now]
    );
    const dbResponse = rows;

    console.info(
      `New review has been successfully created: ${JSON.stringify(
        dbResponse[0]
      )}`
    );

    const category = (await fetchCategoriesFromDB(categoryId))[0];

    successMessage.data = {
      id: dbResponse[0].id,
      userId: dbResponse[0].user_id,
      category: {
        id: categoryId,
        name: category.name,
        uid: category.uid,
      },
      review: dbResponse[0].review,
      rating: dbResponse[0].rating,
      createdAt: dbResponse[0].created_at,
      updatedAt: dbResponse[0].updated_at,
    };

    return res.status(status.success).send(successMessage);
  } catch (exception) {
    console.error(
      `An unhandled exception occurred while saving a new review: ${exception.message}`
    );

    errorMessage.error = exception.message;
    return res.status(status.error).send(errorMessage);
  }
};

/**
 * Fetches a list of user's reviews
 * @param {object} req
 * @param {object} res
 * @returns {object} reflection object
 */
const getReviews = async (req, res) => {
  const { userId } = req.params;

  console.info(`Started fetching reviews for user ${userId}`);

  const query = `
  SELECT
    r.id,
    r.user_id,
    u.username,
    r.category_id,
    c.name AS category_name,
    c.uid AS category_uid,
    r.review,
    r.rating,
    r.created_at,
    r.updated_at
  FROM reviews AS r
  INNER JOIN categories AS c ON r.category_id = c.id
  INNER JOIN users AS u on r.user_id = u.id
  WHERE
    r.user_id = $1
  ORDER BY r.updated_at DESC, r.created_at DESC
  `;

  try {
    const { rows } = await dbQuery.query(query, [userId]);
    const dbResponse = rows;

    if (dbResponse[0] === undefined) {
      successMessage.data = null;
      return res.status(status.success).send(successMessage);
    }

    successMessage.data = dbResponse.map((row) => {
      return {
        id: row.id,
        user: {
          id: row.user_id,
          username: row.username,
        },
        category: {
          id: row.category_id,
          name: row.category_name,
          uid: row.category_uid,
        },
        rating: row.rating,
        review: row.review,
        createdAt: row.created_at,
        updatedAt: row.updated_at,
      };
    });

    console.info(
      `Reviews have been successfully fetched: ${JSON.stringify(dbResponse[0])}`
    );

    return res.status(status.success).send(successMessage);
  } catch (error) {
    console.error(error);

    errorMessage.error = error.message;
    return res.status(status.error).send(errorMessage);
  }
};

/**
 * Fetches a list of all reviews
 * @param {object} req
 * @param {object} res
 * @returns {object} reflection object
 */
const getAllReviews = async (req, res) => {
  console.info(`Started fetching reviews for all users`);

  const query = `
  SELECT
    r.id,
    r.user_id,
    u.username,
    r.category_id,
    c.name AS category_name,
    c.uid AS category_uid,
    r.review,
    r.rating,
    r.created_at,
    r.updated_at
  FROM reviews AS r
  INNER JOIN categories AS c ON r.category_id = c.id
  INNER JOIN users AS u on r.user_id = u.id
  ORDER BY r.updated_at DESC, r.created_at DESC
  `;

  try {
    const { rows } = await dbQuery.query(query);
    const dbResponse = rows;

    if (dbResponse[0] === undefined) {
      successMessage.data = null;
      return res.status(status.success).send(successMessage);
    }

    successMessage.data = dbResponse.map((row) => {
      return {
        id: row.id,
        user: {
          id: row.user_id,
          username: row.username,
        },
        category: {
          id: row.category_id,
          name: row.category_name,
          uid: row.category_uid,
        },
        rating: row.rating,
        review: row.review,
        createdAt: row.created_at,
        updatedAt: row.updated_at,
      };
    });

    console.info(`Reviews have been successfully fetched`);

    return res.status(status.success).send(successMessage);
  } catch (error) {
    console.error(error);

    errorMessage.error = error.message;
    return res.status(status.error).send(errorMessage);
  }
};

/**
 * Fetches statistics of reviews
 * @param {object} req
 * @param {object} res
 * @returns {object} reflection object
 */
const getReviewsStatistics = async (req, res) => {
  console.info(`Started fetching reviews for all users`);

  const query = `
  SELECT
    c.id AS category_id,
    c.name AS category_name,
    c.uid AS category_uid,
    COUNT(r.id) AS reviews,
    COALESCE(AVG(rating), 0) AS average_rating
  FROM categories AS c
  LEFT JOIN reviews AS r ON r.category_id = c.id
  GROUP BY c.id, c.name, c.uid
  ORDER BY 2 ASC
  `;

  try {
    const { rows } = await dbQuery.query(query);
    const dbResponse = rows;

    if (dbResponse[0] === undefined) {
      successMessage.data = null;
      return res.status(status.success).send(successMessage);
    }

    successMessage.data = dbResponse.map((row) => {
      return {
        category: {
          id: row.category_id,
          name: row.category_name,
          uid: row.category_uid,
        },
        rating: row.average_rating,
        reviews: row.reviews,
      };
    });

    console.info(`Reviews have been successfully fetched`);

    return res.status(status.success).send(successMessage);
  } catch (error) {
    console.error(error);

    errorMessage.error = error.message;
    return res.status(status.error).send(errorMessage);
  }
};

/**
 * Updates an existing review
 * @param {object} req
 * @param {object} res
 * @returns {object} reflection object
 */
const updateReview = async (req, res) => {
  const { userId, reviewId } = req.params;
  const { categoryId, rating, review } = req.body;

  console.info(`Started deleting user ${userId}'s review ${reviewId}`);

  try {
    const { rows } = await dbQuery.query(
      `
      UPDATE reviews
      SET
        category_id = $1,
        rating = $2,
        review = $3,
        updated_at = $4
      WHERE
        id = $5
      RETURNING *
      `,
      [categoryId, rating, review, moment(), reviewId]
    );
    const dbResponse = rows;

    console.info(
      `New review has been successfully created: ${JSON.stringify(
        dbResponse[0]
      )}`
    );

    const category = (await fetchCategoriesFromDB(categoryId))[0];

    successMessage.data = {
      id: dbResponse[0].id,
      userId: dbResponse[0].user_id,
      category: {
        id: category.id,
        name: category.name,
        uid: category.uid,
      },
      review: dbResponse[0].review,
      rating: dbResponse[0].rating,
      createdAt: dbResponse[0].created_at,
      updatedAt: dbResponse[0].updated_at,
    };

    return res.status(status.success).send(successMessage);
  } catch (exception) {
    console.error(
      `An unhandled exception occurred while saving a new review: ${exception.message}`
    );

    errorMessage.error = exception.message;
    return res.status(status.error).send(errorMessage);
  }
};

/**
 * Deletes a review
 * @param {object} req
 * @param {object} res
 * @returns {object} reflection object
 */
const deleteReview = async (req, res) => {
  const { userId, reviewId } = req.params;

  console.info(`Started deleting user ${userId}'s review ${reviewId}`);

  try {
    const { rows } = await dbQuery.query(
      `
      DELETE FROM reviews
      WHERE
        id = $1
      `,
      [reviewId]
    );
    const dbResponse = rows;

    console.info(
      `User ${userId}'s review ${reviewId} has been successfully deleted`
    );

    successMessage.data = null;

    return res.status(status.success).send(successMessage);
  } catch (exception) {
    console.error(
      `An unhandled exception occurred while saving a new review: ${exception.message}`
    );

    errorMessage.error = exception.message;
    return res.status(status.error).send(errorMessage);
  }
};

export {
  createReview,
  getReviews,
  updateReview,
  deleteReview,
  getAllReviews,
  getReviewsStatistics,
};

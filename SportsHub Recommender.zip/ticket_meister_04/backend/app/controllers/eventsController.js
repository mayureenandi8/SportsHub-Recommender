import axios from "axios";
import dotenv from "dotenv";
import moment from "moment";

import dbQuery from "../db/dbQuery";
import { errorMessage, successMessage, status } from "../helpers/status";

dotenv.config();

class InvalidFilterError extends Error {
  constructor(...params) {
    super(...params);

    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, InvalidFilterError);
    }

    this.name = "InvalidFilterError";
  }
}

const getQuery = (req) => {
  const validFilters = [
    "categoryId",
    "name",
    "startDateTime",
    "endDateTime",
    "state",
    "city",
    "address",
  ];
  let query = "";

  if (req.params) {
    for (let i = 0; i < req.params.length; i++) {
      const filter = validFilters[i];
      const filterValue = req.params[filter];

      query += `${filter}`;

      filterStatement += `${filter} = '${filterValue}'`;
    }
  }

  return filterStatement;
};

const fetchCategoriesFromDB = async (categoryId = undefined) => {
  console.log("Started fethcing categories from the DB");

  try {
    let dbResponse = null;

    if (categoryId == undefined) {
      const { rows } = await dbQuery.query(`
        SELECT
          *
        FROM categories`);

      dbResponse = rows;
    } else {
      const { rows } = await dbQuery.query(
        `
        SELECT
          *
        FROM categories
        WHERE
          id = $1`,
        [categoryId]
      );

      dbResponse = rows;
    }

    if (dbResponse[0] === undefined) {
      console.log("There are no categories in the DB");

      return [];
    } else {
      console.log("Successfully fetched categories from the DB");

      return dbResponse.map((row) => {
        return {
          id: row.id,
          name: row.name,
          uid: row.uid,
        };
      });
    }
  } catch (exception) {
    console.error(
      `An unexpected exception occurred during fetching categories from the DB: ${exception.message}`
    );
    throw exception;
  }
};

const saveCategoriesInDB = async (categories) => {
  console.log("Started saving categories into the DB");

  try {
    const insertedCategories = [];

    for (const category of categories) {
      const { rows } = await dbQuery.query(
        `
        INSERT INTO categories
        (
          name,
          uid
        )
        VALUES ($1, $2)
        RETURNING *
        `,
        [category.name, category.uid]
      );
      const dbResponse = rows[0];

      if (dbResponse === undefined) {
        throw Error(
          "An unexpected exception occurred while saving a category into the DB"
        );
      }

      insertedCategories.push({
        id: dbResponse.id,
        name: dbResponse.name,
        uid: dbResponse.uid,
      });
    }

    console.log("Successfully saved categories into the DB");

    return insertedCategories;
  } catch (exception) {
    console.error(
      `An unexpected error occurred during saving categories into the DB: ${exception.message}`
    );
  }
};

const fetchCategoriesFromTicketMaster = async () => {
  console.log("Started fetching categories from TicketMaster");

  try {
    const response = await axios.get(
      `https://app.ticketmaster.com/discovery/v2/classifications.json?apikey=${process.env.TICKET_MASTER_API_KEY}`
    );
    const classifications = response.data._embedded.classifications
      .filter(
        (classification) =>
          classification.hasOwnProperty("segment") &&
          // FIXME: We fetch only sports categories
          classification.segment.name === "Sports"
      )
      .map((classification) => classification.segment)[0];
    const categories = classifications._embedded.genres.map((genre) => {
      return {
        uid: genre.id,
        name: genre.name,
      };
    });

    console.log("Successfully fetched categories from TicketMaster");

    return categories;
  } catch (exception) {
    console.error(
      `An unexpected exception occurred during fetching categories from TicketMaster: ${exception.message}`
    );
    throw exception;
  }
};

/**
 * Creates a new review
 * @param {object} req
 * @param {object} res
 * @returns {object} reflection object
 */
const getCategories = async (req, res) => {
  console.log("Started fetching categories");

  try {
    let categories = await fetchCategoriesFromDB();

    if (categories.length === 0) {
      categories = await fetchCategoriesFromTicketMaster();
      categories = await saveCategoriesInDB(categories);
    }

    console.log("Successfully fetched categories");

    successMessage.data = categories;
    return res.status(status.success).send(successMessage);
  } catch (exception) {
    console.error(
      `An unexpected exception occurred during fetching categories: ${exception.message}`
    );

    errorMessage.error = exception.message;
    return res.status(status.error).send(errorMessage);
  }
};

const getEvents = async (req, res) => {
  let query = "";

  console.log(`${JSON.stringify(req.query)}`);

  if (req.query.hasOwnProperty("zipcode")) {
    query += `&postalCode=${req.query.zipcode}`;
  }
  if (
    req.query.hasOwnProperty("categoryId") &&
    req.query.categoryId &&
    req.query.categoryId !== "undefined"
  ) {
    query += `&genreId=${req.query.categoryId}`;
  } else {
    query += "&classificationName=Sports";
  }
  if (req.query.hasOwnProperty("latLng") && req.query.latLng) {
    query += `&latlong=${req.query.latLng}`;
  }

  // FIXME: TicketMaster API doesn't work correctly in the case of multiple filters.
  //        It means we have to filter on the backend
  // if (req.query.hasOwnProperty("startDateTime") && req.query.startDateTime) {
  //   query += `&startDateTime=${
  //     moment(req.query.startDateTime).format("YYYY-MM-DDTHH:mm:ss") + "Z"
  //   }`;
  // }
  // if (req.query.hasOwnProperty("endDateTime") && req.query.endDateTime) {
  //   query += `&endDateTime=${
  //     moment(req.query.endDateTime).format("YYYY-MM-DDTHH:mm:ss") + "Z"
  //   }`;
  // }

  let startDateTime = null;
  let endDateTime = null;

  if (req.query.hasOwnProperty("startDateTime") && req.query.startDateTime) {
    startDateTime = moment(req.query.startDateTime);
  }
  if (req.query.hasOwnProperty("endDateTime") && req.query.endDateTime) {
    endDateTime = moment(req.query.endDateTime);
  }

  let url = `https://app.ticketmaster.com/discovery/v2/events.json?apikey=${process.env.TICKET_MASTER_API_KEY}`;

  if (query) {
    url += query;
  }

  console.log(`url = ${url}`);

  const response = await axios.get(url);

  if (!response.data.hasOwnProperty("_embedded")) {
    successMessage.data = null;
  } else {
    const events = [];

    for (const event of response.data._embedded.events) {
      const processedEvent = {
        name: event.name,
        url: event.url,
      };

      if (event.dates.start.hasOwnProperty("dateTime")) {
        processedEvent.startDateTime = moment(event.dates.start.dateTime);
      } else {
        processedEvent.startDateTime = moment(event.dates.start.localDate);
      }

      if (event.dates.hasOwnProperty("end")) {
        if (event.dates.end.hasOwnProperty("dateTime")) {
          processedEvent.endDateTime = moment(event.dates.end.dateTime);
        } else {
          processedEvent.endDateTime = moment(event.dates.end.localDate);
        }
      }

      // Let's filter out all past events
      if (
        startDateTime &&
        processedEvent.startDateTime &&
        !processedEvent.endDateTime &&
        processedEvent.startDateTime < startDateTime
      ) {
        continue;
      }

      if (
        startDateTime &&
        processedEvent.startDateTime &&
        processedEvent.endDateTime &&
        processedEvent.endDateTime < startDateTime
      ) {
        continue;
      }

      if (
        endDateTime &&
        processedEvent.startDateTime &&
        processedEvent.startDateTime > endDateTime
      ) {
        continue;
      }

      if (event.hasOwnProperty("priceRanges")) {
        processedEvent.priceRanges = event.priceRanges;
      }

      if (event._embedded.venues.length > 0) {
        const venue = event._embedded.venues[0];

        if (venue.hasOwnProperty("state")) {
          processedEvent.state = venue.state.stateCode;
        }
        if (venue.hasOwnProperty("country")) {
          processedEvent.country = venue.country.countryCode;
        }
        if (venue.hasOwnProperty("city")) {
          processedEvent.city = venue.city.name;
        }
        if (venue.hasOwnProperty("address")) {
          processedEvent.address = venue.address.line1;
        }

        if (processedEvent.country && processedEvent.country !== "US") {
          continue;
        }
      }

      if (event.hasOwnProperty("classifications")) {
        const classifications = event.classifications;

        for (const classification of classifications) {
          if (!classification.primary) {
            continue;
          }

          if (classification.hasOwnProperty("genre")) {
            processedEvent.category = {
              name: classification.genre.name,
              uid: classification.genre.id,
            };
          } else if (classification.hasOwnProperty("segment")) {
            processedEvent.category = {
              name: classification.segment.name,
              uid: classification.segment.id,
            };
          }
        }
      }

      events.push(processedEvent);
    }

    successMessage.data = events;
  }

  return res.status(status.success).send(successMessage);
};

export { fetchCategoriesFromDB, getCategories, getEvents };

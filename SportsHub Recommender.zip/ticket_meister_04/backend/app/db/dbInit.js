import dbQuery from "../db/dbQuery";

/**
 * Executes a SQL query using the pool of connections
 */
const executeQuery = async (query) => {
  try {
    await dbQuery.query(query);
  } catch (error) {
    console.error(
      `An unexpected error occurred during executing the query: ${error}`
    );
  }
};

const createTable = async (tableName, query) => {
  console.log(`Started creating table ${tableName}`);

  try {
    await executeQuery(query);

    console.log(`Table ${tableName} has been successfully created`);
  } catch (error) {
    console.error(
      `An unexpected exception occurred while creating table ${tableName}`
    );
    throw error;
  }
};

const dropTable = async (tableName, query) => {
  console.log(`Started dropping table ${tableName}`);

  try {
    await executeQuery(query);

    console.log(`Table ${tableName} has been successfully dropped`);
  } catch (error) {
    console.error(
      `An unexpected exception occurred while dropping table ${tableName}`
    );
    throw error;
  }
};

/**
 * Creates categories table
 */
const createCategoriesTable = async () => {
  await createTable(
    "categories",
    `
    CREATE TABLE IF NOT EXISTS categories
    (
      id SERIAL PRIMARY KEY,
      name VARCHAR(100) NOT NULL,
      uid VARCHAR(32) NOT NULL
    )`
  );
};

/**
 * Creates users table
 */
const createUsersTable = async () => {
  await createTable(
    "users",
    `
    CREATE TABLE IF NOT EXISTS users
    (
      id SERIAL PRIMARY KEY,
      first_name VARCHAR(100) NOT NULL,
      last_name VARCHAR(100) NOT NULL,
      address VARCHAR(255) NOT NULL,
      zipcode VARCHAR(5) NOT NULL,
      username VARCHAR(255) UNIQUE NOT NULL,
      password VARCHAR(100) NOT NULL,
      created_at TIMESTAMP NOT NULL
    )`
  );
};

/**
 * Creates users_categories link table.
 * Used for keeping associations between users and their preferred categories
 */
const createUsersCategoriesTable = async () => {
  await createTable(
    "users_categories",
    `
    CREATE TABLE IF NOT EXISTS users_categories
    (
      id SERIAL PRIMARY KEY,
      user_id INT NOT NULL REFERENCES users(id),
      category_id INT NOT NULL REFERENCES categories(id)
    )`
  );
};

/**
 * Creates reviews table
 */
const createReviewsTable = async () => {
  await createTable(
    "reviews",
    `
    CREATE TABLE IF NOT EXISTS reviews
    (
      id SERIAL PRIMARY KEY,
      user_id INT NOT NULL REFERENCES users(id),
      category_id INT NOT NULL REFERENCES categories(id),
      review TEXT NULL,
      rating INT NULL,
      created_at TIMESTAMP NOT NULL,
      updated_at TIMESTAMP NULL
    )`
  );
};

/**
 * Drops categories table
 */
const dropCategoriesTable = async () => {
  await dropTable("categories", "DROP TABLE IF EXISTS categories");
};

/**
 * Drops users table
 */
const dropUsersTable = async () => {
  await dropTable("users", "DROP TABLE IF EXISTS users");
};

/**
 * Drops users_categories table
 */
const dropUsersCategoriesTable = async () => {
  await dropTable("users_categories", "DROP TABLE IF EXISTS users_categories");
};

/**
 * Drops reviews table
 */
const dropReviewsTable = async () => {
  await executeQuery("reviews", "DROP TABLE IF EXISTS reviews");
};

/**
 * Creates all tables
 */
const createAllTables = async () => {
  await createCategoriesTable();
  await createUsersTable();
  await createUsersCategoriesTable();
  await createReviewsTable();
};

/**
 * Drops all tables
 */
const dropAllTables = async () => {
  await dropReviewsTable();
  await dropUsersCategoriesTable();
  await dropUsersTable();
  await dropCategoriesTable();
};

export { createAllTables, dropAllTables };

require("make-runnable");

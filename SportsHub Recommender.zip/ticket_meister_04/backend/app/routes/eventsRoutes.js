import express from "express";

import { getCategories, getEvents } from "../controllers/eventsController";

const router = express.Router();

router.get("/categories", getCategories);
router.get("/events", getEvents);

export default router;

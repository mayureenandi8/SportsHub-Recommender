import express from "express";

import {
  createReview,
  getReviews,
  updateReview,
  deleteReview,
  getAllReviews,
  getReviewsStatistics,
} from "../controllers/reviewsController";

const router = express.Router();

router.post("/users/:userId/reviews", createReview);
router.get("/users/:userId/reviews", getReviews);
router.put("/users/:userId/reviews/:reviewId", updateReview);
router.delete("/users/:userId/reviews/:reviewId", deleteReview);
router.get("/users/reviews", getAllReviews);
router.get("/users/reviews/statistics", getReviewsStatistics);

export default router;

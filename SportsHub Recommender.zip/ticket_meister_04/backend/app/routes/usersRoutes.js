import express from "express";

import { createUser, authenticateUser } from "../controllers/usersController";

const router = express.Router();

router.post("/users", createUser);
router.post("/users/authenticate", authenticateUser);

export default router;

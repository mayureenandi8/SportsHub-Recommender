export const environment = {
  production: true,
  apiUrl: 'http://localhost:5253/api/v1',
};

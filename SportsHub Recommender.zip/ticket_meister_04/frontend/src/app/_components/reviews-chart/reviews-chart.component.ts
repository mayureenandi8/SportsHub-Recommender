import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  ViewEncapsulation,
  AfterViewInit,
} from '@angular/core';
import { CategoryReviewStatistics } from 'src/app/_models';
import * as d3 from 'd3';
import { ReviewsService } from 'src/app/_services';

@Component({
  selector: 'app-reviews-chart',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './reviews-chart.component.html',
  styleUrls: ['./reviews-chart.component.css'],
})
export class ReviewsChartComponent implements AfterViewInit {
  @ViewChild('chart')
  private chartContainer: ElementRef;
  private margin = { top: 20, right: 20, bottom: 30, left: 40 };
  private data: CategoryReviewStatistics[];

  constructor(private reviewsService: ReviewsService) {}

  private createChart(): void {
    if (!this.chartContainer) {
      return;
    }

    d3.select('svg').remove();

    const element = this.chartContainer.nativeElement;
    const contentWidth =
      element.offsetWidth - this.margin.left - this.margin.right;
    const contentHeight =
      element.offsetHeight - this.margin.top - this.margin.bottom;

    if (contentHeight <= 0 || contentWidth <= 0) {
      return;
    }

    const data: CategoryReviewStatistics[] = this.data;
    const svg = d3
      .select(element)
      .append('svg')
      .attr('width', '100%')
      .attr('height', '100%')
      .attr(
        'viewBox',
        '0 0 ' + element.offsetWidth + ' ' + (element.offsetHeight + 100)
      );

    const g = svg
      .append('g')
      .attr('transform', `translate(${this.margin.left}, ${this.margin.top})`);
    const x = d3
      .scaleBand()
      .domain(data.map((item) => item.category.name))
      .rangeRound([0, contentWidth])
      .padding(0.1);
    const y = d3
      .scaleLinear()
      .domain([0, d3.max(data, (item) => +item.reviews)])
      .rangeRound([contentHeight, 0]);
    const xAxis = d3.axisBottom(x).ticks(10);
    const yAxis = d3.axisLeft(y).ticks(4);

    g.append('g')
      .attr('class', 'axis axis--x')
      .attr('transform', 'translate(0,' + contentHeight + ')')
      .call(xAxis)
      .selectAll('text')
      .style('text-anchor', 'end')
      .attr('dx', '-.8em')
      .attr('dy', '-0.6em')
      .attr('transform', function (d) {
        return 'rotate(-90)';
      });

    g.append('g')
      .attr('class', 'axis axis--y')
      .call(yAxis)
      .append('text')
      .attr('transform', 'rotate(-90)')
      .attr('y', 6)
      .attr('dy', '0.71em')
      .attr('text-anchor', 'end')
      .text('Reviews');

    g.selectAll('.bar')
      .data(data)
      .enter()
      .append('rect')
      .attr('class', 'bar')
      .attr('x', (item) => x(item.category.name))
      .attr('y', (item) => y(+item.reviews))
      .attr('width', x.bandwidth())
      .attr('height', (item) => contentHeight - y(+item.reviews));
  }

  public ngAfterViewInit(): void {
    this.reviewsService.reviewStatistics$.subscribe((response) => {
      this.data = response;

      this.createChart();
    });
  }
}

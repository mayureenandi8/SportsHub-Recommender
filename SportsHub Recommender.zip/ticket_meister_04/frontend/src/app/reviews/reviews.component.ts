﻿import {
  Component,
  OnInit,
  OnDestroy,
  ViewChild,
  ViewChildren,
  QueryList,
} from '@angular/core';
import { Subscription, BehaviorSubject } from 'rxjs';

import { User, CategoryReview, Category } from '../_models';
import {
  UserService,
  AuthenticationService,
  EventService,
  ReviewsService,
  AllReviewsService,
} from '../_services';
import { FormBuilder, FormGroup, Validators, NgControl } from '@angular/forms';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { ConfirmationDialogService } from '../_components/confirmation-dialog/confirmation-dialog.service';
import { SortEvent, NgbdSortableHeader } from '../sortable.directive';

export enum ModalDialogType {
  Add,
  Update,
}

@Component({
  templateUrl: 'reviews.component.html',
  styleUrls: ['reviews.component.css'],
})
export class ReviewsComponent implements OnInit {
  public categories: Category[] = [];

  private currentUser: User;

  @ViewChildren(NgbdSortableHeader) headers: QueryList<
    NgbdSortableHeader<Event>
  >;

  @ViewChild('reviewFormModalDialog')
  public reviewFormModalDialog: any;

  public reviewForm: FormGroup;
  public reviewFormDialogType: ModalDialogType = ModalDialogType.Add;
  public reviewModalDialogTitle: string = '';
  public reviewFormSubmitted: boolean = false;

  public loading: boolean = false;

  public ModalDialogType = ModalDialogType;

  constructor(
    private modalService: NgbModal,
    private formBuilder: FormBuilder,
    private confirmationDialogService: ConfirmationDialogService,
    private authenticationService: AuthenticationService,
    private eventService: EventService,
    public reviewsService: ReviewsService,
    public allReviewsService: AllReviewsService
  ) {
    this.authenticationService.currentUser.subscribe((user) => {
      this.currentUser = user;
    });
  }

  private loadCategories(): void {
    this.eventService.getCategories().subscribe((categoriesResponse) => {
      this.categories = categoriesResponse.data;
    });
  }

  private openModalDialog(): void {
    this.modalService.open(this.reviewFormModalDialog, {
      ariaLabelledBy: 'modal-basic-title',
    });
  }

  public ngOnInit(): void {
    this.reviewForm = this.formBuilder.group({
      id: [''],
      category: ['', Validators.required],
      rating: ['', Validators.required],
      review: [''],
    });

    this.loadCategories();
  }

  public onAddNewReview(): void {
    this.reviewFormSubmitted = false;
    this.reviewModalDialogTitle = 'Add review';
    this.reviewFormDialogType = ModalDialogType.Add;

    this.reviewForm.controls.id.setValue(null);
    this.reviewForm.controls.category.setValue(null);
    this.reviewForm.controls.rating.setValue(null);
    this.reviewForm.controls.review.setValue(null);

    this.openModalDialog();
  }

  public onUpdateReview(review: CategoryReview): void {
    this.reviewFormSubmitted = false;
    this.reviewModalDialogTitle = 'Update review';
    this.reviewFormDialogType = ModalDialogType.Update;

    this.reviewForm.controls.id.setValue(review.id);
    this.reviewForm.controls.category.setValue(review.category.id);
    this.reviewForm.controls.rating.setValue(review.rating);
    this.reviewForm.controls.review.setValue(review.review);

    this.openModalDialog();
  }

  public onDeleteReview(review: CategoryReview): void {
    this.confirmationDialogService
      .confirm('Delete a review', 'Do you really want to delete this review?')
      .then((confirmed) => {
        if (confirmed) {
          this.reviewsService.deleteReview(this.currentUser, review);
        }
      });
  }

  public createReview() {
    this.reviewsService.createReview(
      this.currentUser,
      this.reviewForm.controls.category.value,
      this.reviewForm.controls.rating.value,
      this.reviewForm.controls.review.value
    );
  }

  public updateReview(): void {
    this.reviewsService.updateReview(
      this.currentUser,
      this.reviewForm.controls.id.value,
      this.reviewForm.controls.category.value,
      this.reviewForm.controls.rating.value,
      this.reviewForm.controls.review.value
    );
  }

  public onSubmitReviewForm(): boolean {
    this.reviewFormSubmitted = true;

    if (this.reviewForm.invalid) {
      return false;
    }

    this.loading = true;

    if (this.reviewFormDialogType === ModalDialogType.Add) {
      this.createReview();
    } else {
      this.updateReview();
    }

    return true;
  }

  onSort({ column, direction }: SortEvent<CategoryReview>) {
    // resetting other headers
    this.headers.forEach((header) => {
      if (header.sortable !== column) {
        header.direction = '';
      }
    });

    this.reviewsService.sortColumn = column;
    this.reviewsService.sortDirection = direction;
  }
}

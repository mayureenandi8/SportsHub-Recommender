﻿export * from "./reviews.component";

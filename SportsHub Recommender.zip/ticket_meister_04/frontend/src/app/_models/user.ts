﻿export interface User {
  id: number;
  username: string;
  password: string;
  firstName: string;
  lastName: string;
  zipcode: string;
  token: string;
}

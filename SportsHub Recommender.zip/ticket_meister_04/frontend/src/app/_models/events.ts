import { User } from '.';

export interface Category {
  id: string;
  name: string;
  uid: string;
}

export interface LatLng {
  lat: number;
  lng: number;
}

export interface Event {
  name: string;
  url: string;
  startDateTime: Date;
  endDateTime: Date;
  state: string;
  city: string;
  address: string;
  category: Category;
}

export interface CategoryReview {
  id: number;
  user: User;
  category: Category;
  rating: number;
  review: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface CategoryReviewStatistics {
  category: Category;
  rating: number;
  reviews: number;
}

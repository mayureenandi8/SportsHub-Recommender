﻿import {
  Component,
  OnInit,
  QueryList,
  ViewChildren,
  ViewChild,
} from '@angular/core';
import { Subscription, BehaviorSubject, Observable, of } from 'rxjs';
import { first } from 'rxjs/operators';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { User, Category, Event, LatLng } from '../_models';
import { EventService, AuthenticationService } from '../_services';
import { DecimalPipe } from '@angular/common';
import { NgbdSortableHeader, SortEvent } from '../sortable.directive';
import { AddressAutocompleteComponent } from '../_components/address-autocomplete/address-autocomplete.component';

@Component({
  templateUrl: 'home.component.html',
  styleUrls: ['home.component.css'],
  providers: [EventService, DecimalPipe],
})
export class HomeComponent implements OnInit {
  searchFilterForm: FormGroup;
  currentUser: User;
  currentUserSubscription: Subscription;
  users: User[] = [];
  categories: Category[] = [];
  events: Event[];
  selectedCategory: Category;

  @ViewChildren(NgbdSortableHeader) headers: QueryList<
    NgbdSortableHeader<Event>
  >;

  @ViewChild(AddressAutocompleteComponent)
  address: AddressAutocompleteComponent;

  private currentLatLng: LatLng;

  private readonly _events = new BehaviorSubject<Event[]>(null);
  public readonly events$ = this._events.asObservable();

  constructor(
    private formBuilder: FormBuilder,
    private authenticationService: AuthenticationService,
    public eventService: EventService
  ) {
    this.authenticationService.currentUser.subscribe((user) => {
      this.currentUser = user;
    });
  }

  ngOnInit() {
    this.searchFilterForm = this.formBuilder.group({
      category: [''],
      startDateTime: [''],
      endDateTime: [''],
      zipcode: [''],
    });

    this.eventService.getCategories().subscribe((categories) => {
      this.categories = categories.data;
    });

    const address = this.currentUser.zipcode;
    const geocoder = new google.maps.Geocoder();

    geocoder.geocode({ address: address }, (results, status) => {
      if (status == google.maps.GeocoderStatus.OK) {
        this.address.addresstext.nativeElement.value =
          results[0].formatted_address;
      } else {
        alert('Geocode was not successful for the following reason: ' + status);
      }
    });
  }

  public onSearch() {
    if (!this.address.addresstext.nativeElement.value) {
      this.currentLatLng = null;
    }

    const searchParameters = {
      zipcode: null,
      category: this.searchFilterForm.controls.category.value as Category,
      startDateTime: this.searchFilterForm.controls.startDateTime.value as Date,
      endDateTime: this.searchFilterForm.controls.endDateTime.value as Date,
      latLng: this.currentLatLng,
    };

    this.eventService.searchParameters = searchParameters;
  }

  onSort({ column, direction }: SortEvent<Event>) {
    // resetting other headers
    this.headers.forEach((header) => {
      if (header.sortable !== column) {
        header.direction = '';
      }
    });

    this.eventService.sortColumn = column;
    this.eventService.sortDirection = direction;
  }

  public onSubmit() {}

  public getAddress(place: any) {
    if (place && place.geometry && place.geometry.location) {
      this.currentLatLng = {
        lat: place.geometry.location.lat(),
        lng: place.geometry.location.lng(),
      };
    } else {
      this.currentLatLng = null;
    }
  }
}

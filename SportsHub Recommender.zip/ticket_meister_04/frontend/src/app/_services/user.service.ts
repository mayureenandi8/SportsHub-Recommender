﻿import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { User, ApiResponse, CategoryReview, Category } from '../_models';
import { environment } from 'src/environments/environment';

@Injectable({ providedIn: 'root' })
export class UserService {
  constructor(private http: HttpClient) {}

  public getAll() {
    return this.http.get<User[]>(`${environment.apiUrl}/users`);
  }

  public getById(id: number) {
    return this.http.get(`${environment.apiUrl}/users/${id}`);
  }

  public register(user: User) {
    return this.http.post(`${environment.apiUrl}/users`, user);
  }

  public update(user: User) {
    return this.http.put(`${environment.apiUrl}/users/${user.id}`, user);
  }

  public delete(id: number) {
    return this.http.delete(`${environment.apiUrl}/users/${id}`);
  }

  public createReview(
    user: User,
    categoryId: number,
    rating: number,
    review: string
  ): Observable<ApiResponse<CategoryReview>> {
    return this.http.post<ApiResponse<CategoryReview>>(
      `${environment.apiUrl}/users/${user.id}/reviews`,
      {
        userId: user.id,
        categoryId: categoryId,
        rating: rating,
        review: review,
      }
    );
  }

  public getReviews(user: User): Observable<ApiResponse<CategoryReview[]>> {
    return this.http.get<ApiResponse<CategoryReview[]>>(
      `${environment.apiUrl}/users/${user.id}/reviews`
    );
  }

  public updateReview(
    user: User,
    reviewId: number,
    categoryId: number,
    rating: number,
    review: string
  ): Observable<ApiResponse<CategoryReview>> {
    return this.http.put<ApiResponse<CategoryReview>>(
      `${environment.apiUrl}/users/${user.id}/reviews/${reviewId}`,
      {
        categoryId,
        rating,
        review,
      }
    );
  }

  public deleteReview(
    user: User,
    review: CategoryReview
  ): Observable<ApiResponse<null>> {
    return this.http.delete<ApiResponse<null>>(
      `${environment.apiUrl}/users/${user.id}/reviews/${review.id}`
    );
  }
}

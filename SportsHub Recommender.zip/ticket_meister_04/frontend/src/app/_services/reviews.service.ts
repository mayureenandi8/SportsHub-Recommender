﻿import { Injectable, PipeTransform } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject, Subject, of } from 'rxjs';

import {
  User,
  ApiResponse,
  CategoryReview,
  CategoryReviewStatistics,
} from '../_models';
import { environment } from 'src/environments/environment';
import { SortColumn, SortDirection } from '../sortable.directive';
import { DecimalPipe } from '@angular/common';
import { tap, debounceTime, switchMap, delay } from 'rxjs/operators';
import { AuthenticationService } from './authentication.service';

interface SearchResult {
  events: CategoryReview[];
  total: number;
}

interface State {
  page: number;
  pageSize: number;
  searchTerm: string;
  sortColumn: SortColumn<CategoryReview>;
  sortDirection: SortDirection;
}

function matches(review: CategoryReview, term: string, pipe: PipeTransform) {
  return review.review
    ? review.review.toLowerCase().includes(term.toLowerCase())
    : review;
}

const compare = (v1: string, v2: string) => (v1 < v2 ? -1 : v1 > v2 ? 1 : 0);

function sort(
  reviews: CategoryReview[],
  column: SortColumn<CategoryReview>,
  direction: string
): CategoryReview[] {
  if (direction === '' || column === '') {
    return reviews;
  } else {
    return [...reviews].sort((a, b) => {
      const res = compare(`${a[column]}`, `${b[column]}`);
      return direction === 'asc' ? res : -res;
    });
  }
}

@Injectable({ providedIn: 'root' })
export class ReviewsService {
  private readonly _loading$ = new BehaviorSubject<boolean>(true);
  private readonly _reviews$ = new BehaviorSubject<CategoryReview[]>([]);
  private _search$ = new BehaviorSubject<CategoryReview[]>([]);
  private readonly _total$ = new BehaviorSubject<number>(0);

  private currentUser: User;

  private readonly _reviewStatistics = new BehaviorSubject<
    CategoryReviewStatistics[]
  >([]);

  public readonly reviewStatistics$ = this._reviewStatistics.asObservable();

  private _state: State = {
    page: 1,
    pageSize: 5,
    searchTerm: '',
    sortColumn: '',
    sortDirection: '',
  };

  constructor(
    private http: HttpClient,
    private pipe: DecimalPipe,
    private authenticationService: AuthenticationService
  ) {
    this.authenticationService.currentUser.subscribe((user) => {
      this.currentUser = user;

      if (this.currentUser != null) {
        this.reload();
      }
    });

    this._search$
      .pipe(
        tap(() => this._loading$.next(true)),
        debounceTime(200),
        switchMap((events) => this._search(events)),
        delay(200),
        tap(() => this._loading$.next(false))
      )
      .subscribe((result) => {
        this._reviews$.next(result.events);
        this._total$.next(result.total);
      });

    this.reload();
  }

  get reviews$() {
    return this._reviews$.asObservable();
  }
  get total$() {
    return this._total$.asObservable();
  }
  get loading$() {
    return this._loading$.asObservable();
  }
  get page() {
    return this._state.page;
  }
  get pageSize() {
    return this._state.pageSize;
  }
  get searchTerm() {
    return this._state.searchTerm;
  }

  set page(page: number) {
    this._set({ page });
  }
  set pageSize(pageSize: number) {
    this._set({ pageSize });
  }
  set searchTerm(searchTerm: string) {
    this._set({ searchTerm });
  }
  set sortColumn(sortColumn: SortColumn<CategoryReview>) {
    this._set({ sortColumn });
  }
  set sortDirection(sortDirection: SortDirection) {
    this._set({ sortDirection });
  }

  private _set(patch: Partial<State>) {
    Object.assign(this._state, patch);

    this.reload();
  }

  private _search(events: CategoryReview[]): Observable<SearchResult> {
    const {
      sortColumn,
      sortDirection,
      pageSize,
      page,
      searchTerm,
    } = this._state;

    if (!events) {
      events = [];
    }

    // 1. sort
    events = sort(events, sortColumn, sortDirection);

    // // 2. filter
    events = events.filter((country) =>
      matches(country, searchTerm, this.pipe)
    );
    const total = events.length;

    // 3. paginate
    events = events.slice(
      (page - 1) * pageSize,
      (page - 1) * pageSize + pageSize
    );

    return of({ events, total });
  }

  private reload(): void {
    this.getReviews(this.currentUser).subscribe((response) => {
      this._search$.next(response.data);
    });

    this.getReviewsStatistics().subscribe((response) => {
      this._reviewStatistics.next(response.data);
    });
  }

  private getReviewsStatistics(): Observable<
    ApiResponse<CategoryReviewStatistics[]>
  > {
    return this.http.get<ApiResponse<CategoryReviewStatistics[]>>(
      `${environment.apiUrl}/users/reviews/statistics`
    );
  }

  private getReviews(user: User): Observable<ApiResponse<CategoryReview[]>> {
    return this.http.get<ApiResponse<CategoryReview[]>>(
      `${environment.apiUrl}/users/${user.id}/reviews`
    );
  }

  public createReview(
    user: User,
    categoryId: number,
    rating: number,
    review: string
  ): void {
    this.http
      .post<ApiResponse<CategoryReview>>(
        `${environment.apiUrl}/users/${user.id}/reviews`,
        {
          userId: user.id,
          categoryId: categoryId,
          rating: rating,
          review: review,
        }
      )
      .subscribe(() => {
        this.reload();
      });
  }

  public updateReview(
    user: User,
    reviewId: number,
    categoryId: number,
    rating: number,
    review: string
  ): void {
    this.http
      .put<ApiResponse<CategoryReview>>(
        `${environment.apiUrl}/users/${user.id}/reviews/${reviewId}`,
        {
          categoryId,
          rating,
          review,
        }
      )
      .subscribe((response) => {
        const oldReviews = this._search$.getValue();
        const reviews = oldReviews.map((oldReview) =>
          oldReview.id !== response.data.id ? oldReview : response.data
        );

        this._search$.next(reviews);
      });
  }

  public deleteReview(user: User, review: CategoryReview): void {
    this.http
      .delete<ApiResponse<null>>(
        `${environment.apiUrl}/users/${user.id}/reviews/${review.id}`
      )
      .subscribe((response) => {
        this.reload();
      });
  }
}

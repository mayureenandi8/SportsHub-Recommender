﻿import { Injectable, PipeTransform } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject, Subject, of } from 'rxjs';
import { ApiResponse, LatLng, User } from '../_models';
import { Category, Event } from '../_models';
import { environment } from 'src/environments/environment';
import { SortColumn, SortDirection } from '../sortable.directive';
import { tap, debounceTime, switchMap, delay } from 'rxjs/operators';
import { DecimalPipe } from '@angular/common';
import { AuthenticationService } from './authentication.service';

interface SearchParameters {
  zipcode: string;
  category?: Category;
  startDateTime: Date;
  endDateTime?: Date;
  latLng: LatLng;
}

interface SearchResult {
  events: Event[];
  total: number;
}

interface State {
  page: number;
  pageSize: number;
  searchTerm: string;
  sortColumn: SortColumn<Event>;
  sortDirection: SortDirection;
  searchParameters: SearchParameters;
}

function matches(event: Event, term: string, pipe: PipeTransform) {
  return (
    event.name.toLowerCase().includes(term.toLowerCase()) ||
    pipe.transform(event.state).includes(term) ||
    pipe.transform(event.address).includes(term)
  );
}

const compare = (v1: string, v2: string) => (v1 < v2 ? -1 : v1 > v2 ? 1 : 0);

function sort(
  countries: Event[],
  column: SortColumn<Event>,
  direction: string
): Event[] {
  if (direction === '' || column === '') {
    return countries;
  } else {
    return [...countries].sort((a, b) => {
      const res = compare(`${a[column]}`, `${b[column]}`);
      return direction === 'asc' ? res : -res;
    });
  }
}

@Injectable({ providedIn: 'root' })
export class EventService {
  private readonly _loading$ = new BehaviorSubject<boolean>(true);
  private readonly _events$ = new BehaviorSubject<Event[]>([]);
  private _search$ = new Subject<Event[]>();
  private readonly _total$ = new BehaviorSubject<number>(0);
  private currentUser: User;

  private _state: State = {
    page: 1,
    pageSize: 5,
    searchTerm: '',
    sortColumn: '',
    sortDirection: '',
    searchParameters: null,
  };

  constructor(
    private authenticationService: AuthenticationService,
    private http: HttpClient,
    private pipe: DecimalPipe
  ) {
    this.authenticationService.currentUser.subscribe((user) => {
      this.currentUser = user;
    });

    this._search$
      .pipe(
        tap(() => this._loading$.next(true)),
        debounceTime(200),
        switchMap((events) => this._search(events)),
        delay(200),
        tap(() => this._loading$.next(false))
      )
      .subscribe((result) => {
        this._events$.next(result.events);
        this._total$.next(result.total);
      });

    const searchParameters = {
      zipcode: this.currentUser.zipcode,
      category: null,
      startDateTime: null,
      endDateTime: null,
      latLng: null,
    };

    this.getEvents(searchParameters).subscribe((eventsResponse) => {
      this._search$.next(eventsResponse.data);
    });
  }

  get events$() {
    return this._events$.asObservable();
  }
  get total$() {
    return this._total$.asObservable();
  }
  get loading$() {
    return this._loading$.asObservable();
  }
  get page() {
    return this._state.page;
  }
  get pageSize() {
    return this._state.pageSize;
  }
  get searchTerm() {
    return this._state.searchTerm;
  }
  get searchParameters() {
    return this._state.searchParameters;
  }

  set page(page: number) {
    this._set({ page });
  }
  set pageSize(pageSize: number) {
    this._set({ pageSize });
  }
  set searchTerm(searchTerm: string) {
    this._set({ searchTerm });
  }
  set sortColumn(sortColumn: SortColumn<Event>) {
    this._set({ sortColumn });
  }
  set sortDirection(sortDirection: SortDirection) {
    this._set({ sortDirection });
  }
  set searchParameters(searchParameters: SearchParameters) {
    this._set({ searchParameters });
  }

  private _set(patch: Partial<State>) {
    Object.assign(this._state, patch);

    this.getEvents(this._state.searchParameters).subscribe((events) => {
      this._search$.next(events.data);
    });
  }

  private _search(events: Event[]): Observable<SearchResult> {
    const {
      sortColumn,
      sortDirection,
      pageSize,
      page,
      searchTerm,
      searchParameters,
    } = this._state;

    if (!events) {
      events = [];
    }

    // 1. sort
    events = sort(events, sortColumn, sortDirection);

    // // 2. filter
    events = events.filter((country) =>
      matches(country, searchTerm, this.pipe)
    );
    const total = events.length;

    // 3. paginate
    events = events.slice(
      (page - 1) * pageSize,
      (page - 1) * pageSize + pageSize
    );

    return of({ events, total });
  }

  public getCategories(): Observable<ApiResponse<Category[]>> {
    return this.http.get<ApiResponse<Category[]>>(
      `${environment.apiUrl}/categories`
    );
  }

  public getEvents(
    searchParameters?: SearchParameters
  ): Observable<ApiResponse<Event[]>> {
    let url = `${environment.apiUrl}/events`;
    let filters = [];

    console.log(`category = ${JSON.stringify(searchParameters)}`);

    if (searchParameters && searchParameters.category) {
      filters.push(`categoryId=${searchParameters.category.uid}`);
    }
    if (searchParameters && searchParameters.startDateTime) {
      filters.push(`startDateTime=${searchParameters.startDateTime}`);
    }
    if (searchParameters && searchParameters.endDateTime) {
      filters.push(`endDateTime=${searchParameters.endDateTime}`);
    }
    if (searchParameters && searchParameters.latLng) {
      filters.push(
        `latLng=${searchParameters.latLng.lat},${searchParameters.latLng.lng}`
      );
    } else if (searchParameters && searchParameters.zipcode) {
      filters.push(`zipcode=${searchParameters.zipcode}`);
    }

    // if (state !== undefined) {
    //   filters.push(`state=${state}`);
    // }
    // if (city !== undefined) {
    //   filters.push(`city=${city}`);
    // }
    // if (address !== undefined) {
    //   filters.push(`address=${address}`);
    // }
    if (filters) {
      url += `/?${filters.join('&')}`;
    }

    return this.http.get<ApiResponse<Event[]>>(url);
  }
}
